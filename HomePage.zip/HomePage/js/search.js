  
        jQuery.expr[":"].containsNoCase = function(el, i, m) {
             var search = m[3];
             if (!search) return false;
              return eval("/" + search + "/i").test($(el).text());
          };
 
         jQuery(document).ready(function() {
             // used for the first example in the blog post
                
  
              // cancel the search if the user presses the ESC key
            jQuery('#txtSearch').keyup(function(event) {
                if (event.keyCode == 27) {
                   resetSearch();
               }
            });
  
               // execute the search
            jQuery('#txtSearch').keyup(function() {
              
                  if (jQuery('#txtSearch').val().length > 2) {
                 
                    jQuery('#myTable tr').hide();
                   
                    jQuery('#myTable tr td:containsNoCase(\'' + jQuery('#txtSearch').val() + '\')').parent().show();
                  
                     
               }
               else if (jQuery('#txtSearch').val().length == 0) {
                   // if the user removed all of the text, reset the search
                  resetSearch();
               }

               // if there were no matching rows, tell the user
               if (jQuery('#myTable tr:visible').length == 0) {
                    // remove the norecords row if it already exists
                 
               // add the norecords row
                    jQuery('#myTable').append('<tr class="norecords"><td colspan="5" class="Normal">No records were found</td></tr>');
                }
				else{
					 jQuery('.norecords').remove();
				}
            });
          });
		function resetSearch() {
         // clear the textbox
        jQuery('#txtSearch').val('');
            // show all table rows
             jQuery('#myTable tr').show();
            // remove any no records rows
             jQuery('.norecords').remove();
            // remove the cancel search image
            
            // make sure we re-focus on the textbox for usability
             jQuery('#txtSearch').focus();
         }
        
