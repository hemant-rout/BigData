$(document).ready(function () {


$.ajax({
    url: 'JsonData/BookMark.json',
    dataType: 'json',
    success: function(data) {
	
	
	var uniqueSecs = [];
for(i = 0; i< data.length; i++){    
    if(uniqueSecs.indexOf(data[i].sec) === -1){
        uniqueSecs.push(data[i].sec);        
    }        
}

for(i = 0; i< uniqueSecs.length; i++){    
	        
		 var navname = $('<li><a href="#" class="a">' + uniqueSecs[i]+ '</li>');
			$('.sidebar-nav').append(navname);
          
		  }
		  
		$("li .a").each(function() {
	        
			$(this).mouseover(function() {
			var randomColor = '#' + Math.floor(Math.random() * 16777215).toString(16);
/*          $(this).css("background-color", randomColor); */
		  $(this).css({
    transition: 'background-color all ease 0.2s',
    "background-color": randomColor
    });
		 });
		 $(this).mouseout(function() {
      $(this).css("background-color", "transparent")
		 });
	    });
		
    },
    error: function(jqXHR, textStatus, errorThrown){
        alert('Error: ' + textStatus + ' - ' + errorThrown);
    }
});

 
	
	
  var trigger = $('.hamburger'),
      overlay = $('.overlay'),
     isClosed = true;

    trigger.click(function () {
      hamburger_cross();      
    });

    function hamburger_cross() {

      if (isClosed == true) {          
        overlay.hide();
        trigger.removeClass('is-open');
        trigger.addClass('is-closed');
        isClosed = true;
      } else {   
        overlay.show();
        trigger.removeClass('is-closed');
        trigger.addClass('is-open');
        isClosed = false;
      }
  }
  
  $('[data-toggle="offcanvas"]').click(function () {
        $('#wrapper').toggleClass('toggled');
  });  
  
  var navname='';
  var link='JsonData/BookMark.json';
   showLinks(navname,link);
$('.sidebar-nav').on(
'click','a',function(){
$('a').css("background-color", "");
$(this).css("background-color", "blue");
navname= $(this).text();
showLinks(navname,link);
});



function showLinks(navname,link)
{

url=link;
$("#myTable").find("tr").remove();
$.ajax({
    url: url,
    dataType: 'JSON',
  
    success: function(data) {
	 for (var i=0; i<data.length; i++) {
	 if(navname=='')
	 {
	 navname=data[0].sec;
	 }
	 
	if(data[i].sec.toLowerCase()==navname.toLowerCase())
	{
		
		var url='';
	if (data[i].url.slice(-1) == '/') {
    url = data[i].url.slice(0, -1);
	}
	else{
	url = data[i].url;
	}
		
            var row = $('<tr><td class="td">Web Site: <a target="_blank" href='+url+'>' + data[i].name+ '</a><span class="glyphicon glyphicon-remove-circle rmv" aria-hidden="true"></span><br><br>Specialization in :<b>'+data[i].desc+'</b></td></tr>');
            $('#myTable').append(row);
		
	}
	
        }
    },
    error: function(jqXHR, textStatus, errorThrown){
        alert('Error: ' + textStatus + ' - ' + errorThrown);
    }
});
document.title=navname;
}

$('#myTable').on(
'click','.rmv',function(){
$(this).closest('tr').remove();
});

$('#myTable').on(
'mouseover','tr',function(){
 $(this).find('.rmv').show();
});
$('#myTable').on(
'mouseout','tr',function(){
$('.rmv').hide();
});


});
